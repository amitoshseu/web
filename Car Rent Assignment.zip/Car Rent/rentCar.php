<!DOCTYPE html>
<html>
<head>

</head>
<body>
<form action="rentCar.php" method="post" >
<table width="500" border="5" align="center">
  <tr>
      <td colspan="5" align="center"><h1>Book a Car</h1></td>
  </tr>  

  <tr>
      <td>Pickup Location:</td>
      <td><input type="text" name="location"  minlength="3"> </td>
  </tr>

   <tr>
   	<td>Pickup Date & time</td>
   	<td><input type="datetime-local"/></td>
   </tr>
   
   <tr>
   	<td>Return Date & time</td>	
   	<td><input type="datetime-local"/></td>
   </tr>
   
   <tr>
   	<td>Age</td>
   	<td>
	  <select>

      <?php
          for ($i=1; $i<=100; $i++)
          {
              ?>   
                  <option value="<?php echo $i;?>"><?php echo $i;?></option>
              <?php
          }
      ?>
    </select>
   	</td>
   </tr>  
  <tr>
      <!-- <td colspan="5" align="center" ><input type="button"  onclick="myFunction" name="submit" value="Book Now"></td> -->
      <td colspan="5" align="center"><button onclick="myFunction()" type="submit">Book Now</button>
  </tr>
</table>
</form>
<div align="center">
<form action="cars.html" method="get" >
    <b ><input type="submit" style="padding: 7px 15px; font-size: 14px;" value="Back to Car galery" ></b>
</form>
</div>
      <script>
      function myFunction() {
          alert("Booking Successfully Done");
      }
      </script>

</body>
</html>