<html>
<head>
  <title>Login Page</title>
</head>
<body>

<form method="post" action="login.php">
<table width="400" border="5" align="center">
  <tr>
      <td colspan="5" align="center"><h1>Login Form</h1></td>
  </tr>  

  <tr>
      <td>Username:</td>
      <td><input type="text" name="username" class="textInput"></td>
  </tr>
  <tr>
      <td>Password:</td>
      <td><input type="password" name="password" class="textInput"></td>
  </tr>
 <tr>
      <td colspan="5" align="center" ><input type="submit" name="login_btn" value="Login"></td>
  </tr>
  
</table>
</form>
<center>
<font color="red" size="6"> Not register yet? </font><a href="signup.php">Sign Up Here</a>
</center>
</body>
</html>
<?php 
  
<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $username = mysqli_real_escape_string($db,$_POST['username']);
      $password = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT id FROM users WHERE username = '$username' and password = '$password'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
    
      if($count == 1) {
         session_register("username");
         $_SESSION['login_user'] = $myusername;
         
         header("location: cars.html");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>



<!-- 
<?php
  session_start();
  //connect to database 
  $db = mysqli_connect("localhost","root","mrgain","authentication");
  if(isset($_POST['login_btn'])){
      session_start();
      $username = mysql_real_escape_string($_POST['username']);
      $password = mysql_real_escape_string($_POST['password']);

      $password = md5($password); 
      $sql = "SELECT * FROM users WHERE username= '$username' AND password='$password'";
      $result = ($db,$sql);

      if(mysqli_num_rows($result) ==1){
        $_SESSION['message']= "you are logged in";
        $_SESSION['username']= $username;
        header("location: cars.html"); 
      }else{
        $_SESSION['message'] = "Username/password combination incorrect";
      }
  }

 ?> -->