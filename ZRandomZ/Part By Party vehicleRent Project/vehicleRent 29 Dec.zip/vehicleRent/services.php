<?php include 'inc/header.php';?>
<link href="https://fonts.googleapis.com/css?family=Vollkorn" rel="stylesheet">

<style type="text/css">
 .blockAbout{
    height: 300px;
    width: 25%;
    margin: 10px;
    text-align: justify;
    font-family: 'Vollkorn', serif;
    font-size: 20px;
    margin-left: 50px;
    padding: 10px;
    border: 2px solid #ddd;
    float: left;
    }

 .testimonial{
    height: 300px;
    width: 30%;
    margin: 10px;
    text-align: justify;
    font-family: 'Vollkorn', serif;
    font-size: 20px;
    margin-right: 20px;
    padding: 10px;
    overflow: scroll;
    /*border: 2px solid #ddd;*/
    float: right;
    }


  .blockAboutFreeSpace{
    height: 100px;
    width: 80%;
    margin: 10px;
    margin:0 auto;
    clear: left;

    }

  .blockAbout2{
  height: 200px;
    width: 100px;
    margin: 10px;
    /*background-color: black;*/
    float: left;
    margin:0 auto;

    }



@import url(http://fonts.googleapis.com/css?family=Roboto:900,300);
body {
  background-color: #f0f0f0;
  font-family: roboto;
}

.containerCard {
  width: 35%;
  margin: 50px auto;
  background-color: #fff;
  padding-left: 10%;
  /*padding: 0 20px 20px;*/
  -moz-border-radius: 6px;
  text-align: center;
  float: left;
}

.avatar-flip {
  border-radius: 10px;
  overflow: hidden;
  height: 60px;
  width: 60px;
  position: relative;
  margin: auto;
  top: -60px;
  box-shadow: 0 0 0 13px #f0f0f0;

}
.avatar-flip img {
  position: relative;
  left: 0;
  top: 0;
  height: 60px;
  width: 60px;
  border-radius: 10px;
}

.containerCard2{
  margin: 20px auto;
  width: 30%;
  margin-left: 10px;
  padding: 15px;
  background-color: #fff;
  padding-left: 10px;
  -moz-border-radius: 6px;
  text-align: center;
  float: left;
}

.avatar-flip2{
  border-radius: 10px;
  overflow: hidden;
  height: 100px;
  width: 100px;
  position: relative;
  margin: auto;
  top: -60px;
  box-shadow: 0 0 0 13px #f0f0f0;

}

.avatar-flip2 img {
  position: relative;
  left: 0;
  top: 0;
   height: 100px;
  width: 100px;
  border-radius: 10px;
}


h2 {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 15px;
  color: #333;
}
h4 {
  font-size: 13px;
  color: #00baff;
  letter-spacing: 1px;
  margin-bottom: 25px
}
p {
  font-size: 16px;
  line-height: 26px;
  margin-bottom: 20px;
  color: #666;
}

.boxDiv1{
	margin: 0 auto;

}
</style>

<div class="blockAbout">
  <!-- <div class="blockAbout2"></div><br> -->
  <h2 style="font-size: 35px;">Get to know who we are</h2>

  We are connected with the top Vehicle rental companies in Dhaka distric and Dhaka city. The first of its kind service in Bangladesh, you can order Cars anytime in Bangladesh.
<br>
<button onclick="myFunction()" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white; margin-left:auto;margin-right:auto;display:block;" >Read More</button></b>
</div>

<div class="blockAbout">
  <!-- <div class="blockAbout2"></div><br> -->
  <h2 style="font-size: 35px;">News blog and other articles </h2>

  We are connected with the top Vehicle rental companies in Dhaka distric and Dhaka city. The first of its kind service in Bangladesh, you can order Cars anytime in Bangladesh.
<br>
<button onclick="myFunction()" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white; margin-left:auto;margin-right:auto;display:block;" >Read More</button></b>
</div>



<div class="testimonial" >
  <h2>Testimonial</h2>
    
  <p>This vehicleRent service is really good and i like this website feature </p>
  <p>-------Mr. Cookie</p>
  <p>This vehicleRent service is really good and i like this website feature </p>
  <p>-------Mr. Cookie</p>
  <p>This vehicleRent service is really good and i like this website feature </p>
  <p>-------Mr. Cookie</p>


 

</div>


<div class="blockAboutFreeSpace"></div>
<div class="blockAboutFreeSpace"></div>


<div class="containerCard2">
  <div class="avatar-flip2">
    <img src="images/carDemand.jpg" height="150" width="150">
  </div>
  <h2>CAR ON DEMAND</h2>
  <p>Our Vehicle rent website always try tu fulfill our customer Demans. Request a ride and they will arrive in time. Enjoy the ride and pay cash (Limited Service).</p>
</div>

<div class="containerCard2">
  <div class="avatar-flip2">
    <img src="images/preReserve.jpg" height="150" width="150">
  </div>
  <h2>PRE-RESERVATION</h2>
  <p>Reserve car, motorcycle and minitruck by our website, Phone, SMS, FB Messenger and email. You will see your car Just In Time.</p>
</div>

<div class="containerCard2">
  <div class="avatar-flip2">
    <img src="images/plane.jpg" height="150" width="150">
  </div>
  <h2>AIRPORT PICKUP</h2>
  <p>Our drivers are always ready for Airport drop off and pick up. Just provide your flight information and Our driver will be there accordingly.</p>
</div>




<h2 align="center"  style="font-size: 35px; clear: left" >Advantages</h2>
<h3 align="center">Because we care our customer</h3>
<p align="center">-----------------------------</p>

<div class="blockAboutFreeSpace"></div>



<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/run.png" height="150" width="150">
  </div>
  <h2>COMPETITIVE FARE</h2>
  <p>We fare are calculated based on base fee, time, distance, and Trust & Safety Fee. We frequently change our price based on demand and supply. So, Our fare is always competitive compared to other similar transportation services.</p>
</div>

<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/driver.png" height="150" width="150">
</div>
  <h2>RELIABLE DRIVER</h2>
  <p>Our drivers have minimum 5 years driving experience, able to speak Basic English, polite and co-operative. We provide you best service. We strive to provide you with the best service and experience.</p>
</div>

<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/gtCar.jpg" height="150" width="150">
</div>

  <h2>GREAT CAR</h2>
  <p>We uses,newer model and upscale/renowned branded cars, byke, and minitruck. Each car is clean and well maintained to ensure you a comfortable and safe ride.</p>
</div>

<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/minute.jpg" height="150" width="150">
</div>
  <h2>ETA 30 MINUTES AND UP</h2>
  <p>We are working hard to ensure your car arrives in 30 minutes on average whenever you request a car. We are adding new drivers every day in our system to ensure you prompt service.</p>
</div>



<?php include 'inc/footer.php';?>