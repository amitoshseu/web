<?php 
	$filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/Database.php');
	include_once ($filepath.'/../helpers/Format.php');
	
?>
   

<?php 
	/**
	* 
	*/
	class Reserve{
		private $db;
		private $fm;

		public function __construct()
		{
			$this->db = new Database();
			$this->fm = new Format();
		}

		public function addToReserve($data,$id){
		$vehicleId	   = mysqli_real_escape_string($this->db->link,$id);
		$sId		   = session_id();
		$tryTrip	   = mysqli_real_escape_string($this->db->link,$data['tryTrip']);
		$vehicleNumber = mysqli_real_escape_string($this->db->link,$data['vehicleNumber']);
		$datePick 	   = mysqli_real_escape_string($this->db->link,$data['datePick']);
		$timePick 	   = mysqli_real_escape_string($this->db->link,$data['timePick']);
		$pickAdd		= mysqli_real_escape_string($this->db->link,$data['pickAdd']);
		$endAdd	 		= mysqli_real_escape_string($this->db->link,$data['endAdd']);
		
		$squery = "SELECT * FROM tbl_vehicle WHERE vehicleId = '$vehicleId'";
		$result = $this->db->select($squery)->fetch_assoc();
		
		$vehicleName = $result['vehicleName'];
		$rate 		 = $result['rate'];
		$image		 = $result['image'];

		$chquery = "SELECT * FROM tbl_reserve WHERE vehicleId = '$vehicleId' AND sId='$sId'";
		$getVehi = $this->db->select($chquery);
		if($getVehi){
			$msg = "*Vehicle Already In Reserve List!";
			return $msg;
		}else{

		$query = "INSERT INTO tbl_reserve(sId,vehicleId,vehicleName,
	    	tryTrip,vehicleNumber,datePick,timePick,pickAdd,endAdd,rate,image) VALUES('$sId','$vehicleId','$vehicleName','
	    	$tryTrip','$vehicleNumber','$datePick','$timePick','$pickAdd','$endAdd','$rate','$image')";


		    $inserted_row = $this->db->insert($query);
			if($inserted_row){
				header("Location:reserve.php");
			}else{
				header("Location:404.php");
			}
		}

		}

		public function getReserveVehicle(){
			$sId= session_id();
			$query = "SELECT * FROM tbl_reserve WHERE sId = '$sId'";
			$result = $this->db->select($query);
			return $result;
		}

		public function delVehicleByReserve($delId){
			$delId	   = mysqli_real_escape_string($this->db->link,$delId);
			$query = "DELETE FROM  tbl_reserve WHERE reserveId='$delId'";
			$deldata = $this->db->delete($query);
			if ($deldata) {
				echo "<script>window.location = 'reserve.php'</script>";
			}else{
				$msg="<span class='error'> Vehicle Not Deleted!</span>";
				return $msg;
			}
		}

		public function checkReserveTable(){
			$sId= session_id();
			$query = "SELECT * FROM tbl_reserve WHERE sId = '$sId'";
			$result = $this->db->select($query);
			return $result;
		}

		public function delCustomerReservation(){
			$sId= session_id();
			$query = "DELETE FROM tbl_reserve WHERE sId='$sId'";
			$this->db->delete($query);
		}

		public function bookVehicle($cusId){
			$sId= session_id();
			$query = "SELECT * FROM tbl_reserve WHERE sId = '$sId'";
			$getVehi = $this->db->select($query);
			if ($getVehi) {
				while ($result = $getVehi->fetch_assoc()) {
					$vehicleId = $result['vehicleId'];
					$vehicleName = $result['vehicleName'];
					$tryTrip = $result['tryTrip'];
					$vehicleNumber = $result['vehicleNumber'];
					$datePick = $result['datePick'];
					$timePick = $result['timePick'];
					$pickAdd = $result['pickAdd'];
					$endAdd = $result['endAdd'];
					$rate = $result['rate'];
					$image = $result['image'];

					$query = "INSERT INTO tbl_booking(cusId,vehicleId,vehicleName,tryTrip,pickAdd,
					endAdd,datePick,timePick,vehicleNumber,rate,image) VALUES('$cusId','$vehicleId','$vehicleName','$tryTrip','$pickAdd','$endAdd','$datePick','$timePick','$vehicleNumber','$rate','$image')";


		    $inserted_row = $this->db->insert($query);
				}
			}
		}


	}


 ?>