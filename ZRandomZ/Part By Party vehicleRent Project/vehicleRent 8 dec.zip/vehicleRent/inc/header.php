<!DOCTYPE html>
<html>
<head>
<meta content="text/html;"/>
<title>Car Rent</title>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>


<!-- +++++++++++++++++++++++++++++++++++++++++++++++
   MENU PART
++++++++++++++++++++++++++++++++++++++++++++++++++++-->

<div class="menu-wrap">
  <div class="menu">
    <ul>
      <li><a href="index.php" class="active">home</a></li>
      <li><a href="about.php">about</a></li>
      <li><a href="services.php">Services</a></li>
      <li class="dropdown">
        <a href="#" class="dropbtn">Vehicle ▼</a>
          <div class="dropdown-content">
            <a href="cars.php">Car</a>
            <a href="bike.php">Mini Truck</a>
            <a href="minitruck.php">Motorcycle</a> 
          </div>
      </li>

      <li><a href="contact.php">Contact</a></li>
      
    </ul>
  </div>
</div>




<!-- +++++++++++++++++++++++++++++++++++++++++++++++
    NAME and LOGO PART
++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


<div class="header">
  <div class="logo">
    <h1>Vehicle<span>Rent</span></h1>
  </div>
  <div class="social">
    <!-- <ul>
      <li><a href="http://www.facebook.com/amitoshseu"><img src="images/facebook.png" alt="facebook" /></a></li>
      <li><a href="http://www.twitter.com/amitoshseu"><img src="images/twitter.png" alt="tiwwter" /></a></li>
    </ul> -->
  </div>
</div>
