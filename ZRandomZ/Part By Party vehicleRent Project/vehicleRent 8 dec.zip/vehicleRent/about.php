<?php include 'inc/header.php';?>
<link href="css/aboutStyle.css" rel="stylesheet" type="text/css" />

<div class="shoeb">
      <h1>About Us</h1>
      </div>
        
       
      <ul class="a">
         <li><a href="about.php" class="active">About Us</a></li>
           <li><a href="aboutHistory.php" class="active">History</a></li> 
            <li><a href="aboutTeam.php" class="active">Our Team</a></li>
        </ul>


        <div class="about">
                      <img src="images/abouts.png"></img>

                      <h2>About Vehical Rent</h2>
                        <p> 
                        the largest car rental provider to international travelers visiting Bangladesh, is a value-oriented, internationally recognized brand serving the rental needs of airport leisure travelers. Vehical Rent offers everyday low rental rates and a hassle-free customer experience at the most popular travel destinations throughout the Dhaka, Sylet, Barishal, Chittagong, Khulna and Rongpur.</p>
                        <p>By going directly to VehicalRent.com and registering for free to become an “Vehical Rent Insider,” customers receive a guaranteed member discount of five percent off the retail rate. In addition, Vehical Rent customers in the BD are able to conveniently choose their own vehicles, based upon their advance reservation and requested car class, and then simply drive away from the airport. Vehical Rent more than 171 self-serve kiosks at 630 BD. locations also allow customers to expedite their check-in time and hit the road faster.</p>
                        
                        <p> Customers who book online receive Vehical Rent’s best rates, and receive additional discounts if they choose the “Prepay & Save” option when making their online reservation. 
                        </p>
                        <p> For more information about Vehical Rent, visit Facebook, Pinterest, Google+, or follow @VehicalRent on Twitter.</p>
                       
                        </p>
       </ul>
     
   </div>



<?php include 'inc/footer.php';?>