<?php include 'inc/header.php';?>

<div align="center">
<h3 style="font-size: 40px";>Choose your car</h3>
<ul class="rig" >
	<li>
		<img src="images/car1.jpg" />
		<h3>Economy Car 1<br>6$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car2.jpg" />
		<h3>Economy Car 2<br>6$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car3.jpg" />
		<h3>Economy Car 3<br>6$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car4.jpg" />
		<h3>Standard Car 1<br>10$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car5.jpg" />
		<h3>Standard Car 2<br>10$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car6.jpg" />
		<h3>Standard Car 3<br>10$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car7.jpg" />
		<h3>Lux Car 1<br>12$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car8.jpg" />
		<h3>Lux Car 2<br>12$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
	<li>
		<img src="images/car9.jpg" />
		<h3>Lux Car 3<br>12$/hour</h3>
		<form action="rentCar.php" method="get" >
		<b ><input type="submit" style="padding: 7px 15px; font-size: 14px; background-color: #008CBA; color: white;" value="Click to rentCar" ></b>
		</form>
	</li>
</ul>
</div>




<?php include 'inc/footer.php';?>