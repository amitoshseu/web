<?php include 'inc/header.php';?>

<h3>You successfully Logged In</h3>

<?php include 'inc/footer.php';?>