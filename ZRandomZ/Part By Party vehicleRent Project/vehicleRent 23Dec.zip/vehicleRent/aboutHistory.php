<?php include 'inc/header.php';?>
<link href="css/aboutStyle.css" rel="stylesheet" type="text/css" />



<div class="shoeb">
      <h1>About Us</h1>
      </div>
       <ul class="a">
       
         <li><a href="about.php" class="active">About Us</a></li>
           <li><a href="aboutHistory.php" class="active">History</a></li> 
            <li><a href="aboutTeam.php" class="active">Our Team</a></li>
            </ul>
            <div class="about">
                      <img src="images/about.png"></img>
                    
                    <h2>History of Vheical Rent</h2><br><br>
               
     </ul>
     
   </div>      
    					<div class="green">
  						<p><strong>1974</strong> Vehicle Rent A Car opens four locations in Dhaka, pioneering the concept of Unlimited Free Mileage. Immediately carving its niche in the leisure car rental industry, Vehicle Rent focuses its mission on providing a fun, low-cost, high-value rental experience to family and leisure travelers. The brand quickly becomes one of the country’s largest vacation rental providers and the largest provider to international travelers visiting Bnagladesh.</p>
  						</div><br>
  						<div class="red">
  						<p><strong>1982</strong> To facilitate the increase in leisure travelers, constructs its first state-of-the-art rental plaza in Tampa, Fla. Rental plazas serve hundreds of customers per hour in a modern, ultra-spacious environment. More plazas follow in other major leisure destinations including Orlando, Fla., home of the world’s largest rental facility.</p>
						</div><br>

						<div class="blue">
  						<p><strong>1985</strong> Vehicle Rent introduces a new customized rental agreement the size of an airline ticket, and Instant Vehicle Rent A Car, a program that stores a traveler’s individual rental information for instant reference.</p>
						</div><br>

						<div class="green">
  						<p><strong>1990</strong> Vehicle Rent revolutionizes collision damage waivers by introducing the first-ever price and coverage option for all renters. Alamo creates three new consumer-driven optional collision damage waiver products in Florida, named Waiver Savers®, which provide customers with three choices of price and coverage options tailored to their needs.</p></div><br>
						<div class="red">
  						<p><strong>1995</strong> Vehicle Rent launches the industry’s first real-time Internet booking engine. Customers can visit  VehicleRent.com to find locations, view rates and select their vehicle. Soon,  VehicleRent.com expands to include a membership-services section and travel tools to find the weather, driving directions and fun activities for children to enjoy on their road trip.</p></div><br>

						<div class="blue">
  						<p><strong>1998</strong> Vehicle Rent launches E-Process 2000, a group of technologically enhanced initiatives for tour operators, including electronic reservation links on the company’s website, voucher-less rental processing and electronic billing.</p></div><br>

						<div class="green">
  						<p><strong>2002</strong> Vehicle Rent announces a partnership with Pan Pcific Sonargon and Ruposhi Bangla, making it the official rent a car company of the most frequented tourist attractions in Bangladesh.</p></div><br>
  						<div class="red">
  						<p><strong>2005</strong>Vehicle Rent  launches the industry’s first and only online check-in system.</p></div><br>

						<div class="blue">
  						<p><strong>2011</strong> Vehicle Rent is acquired by the Taylor Family of St. Louis, which today also owns and operates Enterprise Holdings. Vehicle Rent earns Budget Travel magazine’s “Extra Mile Award” for its self-serve kiosks.</p></div><br>

						<div class="green">
  						<p><strong>2016</strong> Vehicle Rent launches a partnership with Japan Airlines (JAL) which allows members of JAL’s frequent flyer program to earn miles when renting from any participating Vehicle Rent location in the Sylet. and Chittagong.</p></div><br>


<?php include 'inc/footer.php';?>