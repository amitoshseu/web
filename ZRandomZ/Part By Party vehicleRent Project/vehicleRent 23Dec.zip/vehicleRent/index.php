<?php include 'inc/header.php';?>
<?php include 'inc/slideshow.php';?>

<!-- +++++++++++++++++++++++++f++++++++++++++++++++++
    BOOKING,SIGNUP,LOGIN
++++++++++++++++++++++++++++++++++++++++++++++++++++-->

<br><br>
<br><br>
<div class="tabDiv"  id="goTo">
<div class="wholeTab">
  <ul class="tab">
    <li><a href="javascript:void(0)" class="tablinks"  onclick="signupPlease(event, 'Booking')" id="defaultOpen">Booking</a></li>
    <li><a href="javascript:void(0)" class="tablinks" id="goToReg"  onclick="signupPlease(event, 'Register')">Register</a></li>
    <li><a href="javascript:void(0)" class="tablinks" id="goToLogin" onclick="signupPlease(event, 'signIn')">Sign In</a></li>
  </ul>

  <div id="Booking" class="tabcontent">

    <h3>Get your car in 30+ minute in Dhaka. <br>৩০ মিনিটের মধ্যে গাড়ি পেতে বুকিং করুন </h3>
  <form action="index.php#defaultOpen">
    <select id="" class="selectCar">
       <option value="" selected>Select your car</option>
       <option value="sedan">Sedan</option>
       <option value="echo">Echo</option>
       <option value="bike">Bike</option>
       <option value="miniTruck">Mini Truck</option>
       </select>
       
    <select class="selectHire">
        <option value="" selected>Select hiring option</option>
        <option value="">TK.1250: Airport pick up and drop</option>
        <option value="">TK.990: Dhaka city/2 hour</option>
        <option value=""></option>
    </select>
    <input type="text" name="" placeholder="Pick Up Address" class="pickupTextField">
    <input type="date" name="" placeholder="" class="dateSelect">
    <select class="timeSelect">
        <option value="" selected>Time</option>
        <option value="6am">6:00am</option>
        <option value="630am">6:30am</option>
        <option value="7am">7:00am</option>
        <option value="730am">7:30am</option>
        <option value="8am">8:00am</option>
        <option value="830am">8:30am</option>
        <option value="9am">9:00am</option>
        <option value="930am">9:30am</option>
        <option value="10am">10:00am</option>
        <option value="1030am">10:30am</option>
        <option value="11am">11:00am</option>
        <option value="1130am">11:30am</option>
        <option value="12pm">12:00pm</option>
        <option value="1230pm">12:30pm</option>
        <option value="1pm">1:00pm</option>
        <option value="130pm">1:30pm</option>
        <option value="2pm">2:00pm</option>
        <option value="230pm">2:30pm</option>
        <option value="3pm">3:00pm</option>
        <option value="330pm">3:30pm</option>
        <option value="4pm">4:00pm</option>
        <option value="430pm">4:30pm</option>
        <option value="5pm">5:00pm</option>
        <option value="530pm">5:30pm</option>
        <option value="6pm">6:00pm</option>
        <option value="630pm">6:30pm</option>
        <option value="7pm">7:00pm</option>
        <option value="730pm">7:30pm</option>
        <option value="8pm">8:00pm</option>
        <option value="830pm">8:30pm</option>
        <option value="9pm">9:00pm</option>
        <option value="930pm">9:30pm</option>
        <option value="10pm">10:00pm</option>
        <option value="1030pm">10:30pm</option>
        <option value="11pm">11:00pm</option>
        <option value="1130pm">11:30pm</option>
        <option value="12am">12:00am</option>

    </select>
      
    <input type="text" name="" placeholder="First Name" class="fnameField">
    <input type="text" name="" placeholder="Last Name" class="lnameField">
    <input type="text" name="" placeholder="Your Phone Number" class="phoneField">
    <input type="submit" value="Submit" class="submit1">
 </form>
</div>

<?php 
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
        $customerReg = $cmr->customerRegistration($_POST);
    }


?> 

<div id="Register" class="tabcontent">

<?php 
    if (isset($customerReg)) {
        echo $customerReg;
    }

 ?>
<form action="index.php#goToReg" method="post" >
  
    <h3>Register</h3>
    <input type="text" name="name" placeholder="Your Name" class="RegNameField">
    <input type="text" name="phone" placeholder="Your Phone" class="RegPhoneField">
    <input type="text" name="email" placeholder="Your Email" class="RegEmailField">
    <select name="regCombo" class="hearaboutSelect">
        <option value="" selected>How did you hear about us</option>
        <option value="facebook">Facebook</option>
        <option value="newspaper">Newspaper</option>
        <option value="billboard">Billboard</option>
        <option value="mouth">Word of mouth</option>
        <option value="google">Google</option>
        <option value="youtube">Youtube</option>
        <option value="fmRadio">FM radio</option>
        <option value="directSales">Direct sales</option>
    </select>
    <input type="text" name="address" placeholder="Your Address" class="RegNameField">
    <input type="text" name="city" placeholder="Your City" class="RegPhoneField">

  <input type="password" name="pass" placeholder="Enter Password" class="RegEnterPass">
  <input type="password" name="conPass" placeholder="Confirm Password" class="RegConPass">
  <input type="submit" name="register" value="Next Step" class="submit2">
</form>
 </div>
 
<?php 
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
        $custLogin = $cmr->customerLogin($_POST);
    }


?> 
  
  <div id="signIn" class="tabcontent">
  <?php 
    if (isset($custLogin)) {
        echo $custLogin;
    }

 ?>
  <form action="index.php#goToLogin" method="post">
    <h3>Sign In</h3>
    <input type="text" name="email" placeholder="Email" class="SignInEmail">
    <input type="password" name="pass" placeholder="Password" class="SignInPass">
     <input type="submit" name="login" value="Sign In" class="submit3">
  </form>
  </div>

<script type="text/javascript" src="js/booking.js"></script>
</div>
</div>

<!-- +++++++++++++++++++++++++f++++++++++++++++++++++
   WELCOME MESSAGE BLOCK
++++++++++++++++++++++++++++++++++++++++++++++++++++-->

<div class="welcomeMsg">
    <h3>Welcome to our page</h3><br>
    <p>The vahicleRent app is under construction</p>
    <br><br>
    <span style="color: black; font-size:30px">
    <p>আমাদের পেজ ভিজিট করার জন্য অশেষ ধন্যবাদ। আমাদের ওয়েবসাইট এর সংশ্লিষ্ট এপপ্স টির উন্নয়ন চলতেসে। </p></span>
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">
</div>


<?php include 'inc/footer.php';?>

