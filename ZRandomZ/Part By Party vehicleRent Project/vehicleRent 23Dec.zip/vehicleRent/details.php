<?php include 'inc/header.php';?>
<link href="css/detailsStyle.css" rel="stylesheet" type="text/css" media="all"/>


<?php 
    if (!isset($_GET['vehicleid']) || $_GET['vehicleid'] == NULL) {
        echo "<script>window.location='404.php';</script>";
    }else{
       $id = preg_replace('/[^-a-zA-Z0-9_]/','',$_GET['vehicleid']);
    }

 
    // if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //     $brandName  = $_POST['brandName'];
    //     $updateBrand = $brand->brandUpdate($brandName,$id);
    // }


?>

 <div class="main">
    <div class="content">
    	<div class="section group">
				<div class="cont-desc span_1_of_2">		
				<?php 
					$getVehi = $vehi->getSingleVehicle($id);
					if($getVehi){
						while ($result = $getVehi->fetch_assoc()) {
	
				 ?>		
					<div class="grid images_3_of_2">
						<img src="admin/<?php echo $result['image']; ?>" alt="" />
					</div>
				<div class="desc span_3_of_2">
					<h2><?php echo $result['vehicleName']; ?></h2>

					<div class="price">
						<p>Category: <span><?php echo $result['catName']; ?></span></p>
						<p>Rate: <span>$<?php echo $result['rate']; ?></span>/Hour</p>
						<p>Rate: <span>$<?php echo $result['rate']; ?></span>/Day</p>
						<p>Rate: <span>$<?php echo $result['rate']; ?></span>/Airport Transfer</p>
						<p>Brand:<span><?php echo $result['brandName']; ?></span></p>
					</div>
				<!-- <div class="add-cart">
					<form action="cart.html" method="post">
						<input type="number" class="buyfield" name="" value="1"/>
						<input type="submit" class="buysubmit" name="submit" value="Reserve Now"/>
					</form>				
				</div> -->
			</div>
			<div class="product-desc">
			<h2>Vehicle Details</h2>
			<?php echo $result['body']; ?>
	    </div>

		<?php  } }?>	

	</div>
				<div class="rightsidebar span_3_of_1">
					<h2>Brand</h2>
					<ul>
				      <li><a href="productbycat.html">Mobile Phones</a></li>
				      <li><a href="productbycat.html">Desktop</a></li>
				      <li><a href="productbycat.html">Laptop</a></li>
				      <li><a href="productbycat.html">Accessories</a></li>
				      <li><a href="productbycat.html#">Software</a></li>
					   <li><a href="productbycat.html">Sports & Fitness</a></li>
					   <li><a href="productbycat.html">Footwear</a></li>
					   <li><a href="productbycat.html">Jewellery</a></li>
					   <li><a href="productbycat.html">Clothing</a></li>
					   <li><a href="productbycat.html">Home Decor & Kitchen</a></li>
					   <li><a href="productbycat.html">Beauty & Healthcare</a></li>
					   <li><a href="productbycat.html">Toys, Kids & Babies</a></li>
    				</ul>
    		</div>
 		</div>
 	</div>
	</div>
   
<div class="details">
	

  <form action="#">
   
    <select class="selectHire">
        <option value="" selected>Try Trip</option>
        <option value="">Per Hour</option>
        <option value="">Per Day</option>
        <option value="">Airtport Transfer</option>
        <option value=""></option>
    </select>
    <input type="text" name="" placeholder="Pick Up Address" class="pickupTextField">
    
    <input type="date" name="" placeholder="" class="dateSelect">
    <select class="timeSelect">
        <option value="" selected>Time</option>
        <option value="6am">6:00am</option>
        <option value="630am">6:30am</option>
        <option value="7am">7:00am</option>
        <option value="730am">7:30am</option>
        <option value="8am">8:00am</option>
        <option value="830am">8:30am</option>
        <option value="9am">9:00am</option>
        <option value="930am">9:30am</option>
        <option value="10am">10:00am</option>
        <option value="1030am">10:30am</option>
        <option value="11am">11:00am</option>
        <option value="1130am">11:30am</option>
        <option value="12pm">12:00pm</option>
        <option value="1230pm">12:30pm</option>
        <option value="1pm">1:00pm</option>
        <option value="130pm">1:30pm</option>
        <option value="2pm">2:00pm</option>
        <option value="230pm">2:30pm</option>
        <option value="3pm">3:00pm</option>
        <option value="330pm">3:30pm</option>
        <option value="4pm">4:00pm</option>
        <option value="430pm">4:30pm</option>
        <option value="5pm">5:00pm</option>
        <option value="530pm">5:30pm</option>
        <option value="6pm">6:00pm</option>
        <option value="630pm">6:30pm</option>
        <option value="7pm">7:00pm</option>
        <option value="730pm">7:30pm</option>
        <option value="8pm">8:00pm</option>
        <option value="830pm">8:30pm</option>
        <option value="9pm">9:00pm</option>
        <option value="930pm">9:30pm</option>
        <option value="10pm">10:00pm</option>
        <option value="1030pm">10:30pm</option>
        <option value="11pm">11:00pm</option>
        <option value="1130pm">11:30pm</option>
        <option value="12am">12:00am</option>

    </select>
    
	<input type="text" name="" placeholder="End Address" class="endAddress">
	<select class="numOfVehicle">
        <option value="" selected>Num Of Vehicle</option>
        <option value="">1</option>
        <option value="">2</option>
        <option value="">3</option>
        <option value="">4</option>
        <option value="">5</option>
        <option value="">6</option>
    </select>
    <input type="submit" value="Reserve Now" class="submit1">
 </form>
</div>

<?php include 'inc/footer.php';?>