<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "mrgain");
define("DB_NAME", "vehicle_rent");

?>