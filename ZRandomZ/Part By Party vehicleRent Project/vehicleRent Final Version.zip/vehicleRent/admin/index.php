<br><br><br><br><br><br><br><br>
<script>window.location = 'http://localhost/vehicleRent/admin/login.php'</script>
<h2 style="color:red; font-size: 50px" align="center">Access denied</h2>