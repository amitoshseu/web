<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
               <li><a class="menuitem">Site Option</a>
                    <ul class="submenu">
                        <li><a href="titleslogan.php">Title & Slogan</a></li>
                        <li><a href="social.php">Social Media</a></li>
                        <li><a href="copyright.php">Copyright</a></li>
                        
                    </ul>
                </li>
				
                <!--  <li><a class="menuitem">Update Pages</a>
                    <ul class="submenu">
                        <li><a>About Us</a></li>
                        <li><a>Contact Us</a></li>
                    </ul>
                </li> -->
				<li><a class="menuitem">Admin Control</a>
                    <ul class="submenu">
                        <li><a href="addNewAdmin.php">Add New Admin</a> </li>
                        <!-- <li><a href="viewAdminProfile.php">View Profile</a> </li> -->
                        <li><a href="changepassword.php">Change Password</a> </li>
                    </ul>
                </li>

                <li><a class="menuitem">Vehicle Category</a>
                    <ul class="submenu">
                        <li><a href="addcat.php">Add Category</a> </li>
                        <li><a href="catlist.php">Category List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Brand</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Add Brand</a> </li>
                        <li><a href="brandlist.php">Brand List</a> </li>
                    </ul>
                </li>

                <li><a class="menuitem">Vehicle Option</a>
                    <ul class="submenu">
                        <li><a href="vehicleadd.php">Add Vehicle </a> </li>
                        <li><a href="vehiclelist.php">Vehicle List</a> </li>
                    </ul>
                </li>

                <li><a class="menuitem">Driver</a>
                    <ul class="submenu">
                        <li><a href="addDriver.php">Add Driver </a> </li>
                        <li><a href="driverList.php">Driver List</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>