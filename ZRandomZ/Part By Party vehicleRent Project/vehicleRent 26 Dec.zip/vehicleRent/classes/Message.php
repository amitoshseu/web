<?php 
	$filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/Database.php');
	include_once ($filepath.'/../helpers/Format.php');
?>
    

<?php 
	/**
	* 
	*/
	class Message{
		private $db;
		private $fm;

		public function __construct()
		{
			$this->db = new Database();
			$this->fm = new Format();
		}

		public function sendMessage($data){
			$name = mysqli_real_escape_string($this->db->link,$data['name']);
			$company = mysqli_real_escape_string($this->db->link,$data['company']);
			$phone = mysqli_real_escape_string($this->db->link,$data['phone']);
			$email = mysqli_real_escape_string($this->db->link,$data['email']);
			$message = mysqli_real_escape_string($this->db->link,$data['message']);

			$query = "INSERT INTO tbl_contact(name,company,phone,
		    	email,message) VALUES('$name','$company','$phone','$email','$message')";


		    $inserted_row = $this->db->insert($query);
			if($inserted_row){
				$msg = "<span class='success'>Message Sent Successfully</span>";
				return $msg;
			}else{
				$msg = "<span class='error'>Message Does Not Sent </span>";
				return $msg;
	
			}
			}

		public function getAllMessage(){
			$query = "SELECT * FROM tbl_contact ORDER BY id DESC";
			$result = $this->db->select($query);
			return $result;
		}

		public function getAllMessageById($id){
			$query = "SELECT * FROM tbl_contact WHERE id = '$id'";
			$result = $this->db->select($query);
			return $result;
		}



}

	


 ?>