 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright <a href="#">Vehicle Rent Research Team</a>. All Rights Reserved.
        </p>
    </div>
</body>
</html>
