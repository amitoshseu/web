<?php include 'inc/header.php';?>
<link href="css/aboutStyle.css" rel="stylesheet" type="text/css" />

<div class="shoeb">
      <h1>About Us</h1>
      </div>
       <ul class="a">
         <li><a href="about.php" class="active">About Us</a></li>
           <li><a href="aboutHistory.php" class="active">History</a></li> 
            <li><a href="aboutTeam.php" class="active">Our Team</a></li>
        </ul>
     
        
              <div class="about">
                      <img src="images/about_car.png"></img>
                    
                    <h2>Developer Team</h2>><br>
                    <div class="md"><br><br><br><br><br>
                    <img src="images/shoeb.jpg"></img>
                    <h2>Obyed ullah khan</h2>
          <p>CEO & FOUNDER</p>
                    </div>
                    <div class="amitosh">
                    <img src="images/amitosh.jpg"></img>
                    <h3>Amitosh Gain</h3>
          <p>CEO & FOUNDER</p>
                    </div>
                    <div class="tanim">
                    <img src="images/tanim.jpg"></img>
                    <h4>Faysal Ahmed</h4>
          <p>CEO & FOUNDER</p>
                    </div>
     </ul>
     <br><br>
     <br><br>
     <br><br>

<?php include 'inc/footer.php';?>