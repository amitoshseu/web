
<!-- +++++++++++++++++++++++++++++++++++++++++++++++
    AUTOMATIC SLIDESHOW 
++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<div class="firstBlock">
<div class="slideshow-container">
  <div class="mySlides fade">
    <div align="center" class="numbertext">1 / 3</div>
    <img src="images/slide1.jpg" style="width:90%">
    <!-- <div class="text">Car Demo</div> -->
  </div>

  <div align="center" class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="images/slide2.png" "width=90%">
    <!-- <div class="text">Motorcycle Demo</div> -->
  </div>

  <div align="center" class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="images/slide3.jpg" style="width:90%">
    <!-- <div class="text">Minitruck Demo</div> -->
  </div>

  
</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
<br><br><br><br>
<script type="text/javascript" src="js/slideshow.js"></script>
</div>