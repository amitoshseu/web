<?php include 'inc/header.php';?>
<link href="css/aboutUs.css" rel="stylesheet" type="text/css" media="all"/>
<link href="https://fonts.googleapis.com/css?family=Vollkorn" rel="stylesheet">


<div class="blockAbout">
  <img src="images/animatdCar.png" alt="">
  <div class="blockAbout2"></div><br>
  <h2>Car</h2>

  We are connected with the top Vehicle rental companies in Dhaka distric and Dhaka city. The first of its kind service in Bangladesh, you can order Cars anytime in Bangladesh.

</div>

<div class="blockAboutFreeSpace"></div>

<div class="blockAbout">
  <img src="images/animatedMoto.jpg" alt="">
  <div class="blockAbout2"></div><br>
  <h2>Motorcycle</h2>

  We are connected with the top Vehicle rental companies in Dhaka distric and Dhaka city. The first of its kind service in Bangladesh, you can order MotorCycle anytime in Bangladesh.
</div>

<div class="blockAboutFreeSpace"></div>

<div class="blockAbout">
  <img src="images/animatedTruck.jpg" alt="">
  <div class="blockAbout2"></div><br>
  <h2>Mini Truck</h2>

  We are connected with the top Vehicle rental companies in Dhaka distric and Dhaka city. The first of its kind service in Bangladesh, you can order Mini Truck anytime in Bangladesh.
</div>

<div class="blockAboutFreeSpace"></div>
<div class="blockAboutFreeSpace"></div>



<h2 align="center">Developers Team</h2>

<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/amitosh.jpg" height="150" width="150">
    <img src="images/amitosh2.jpg" height="150" width="150">
  </div>
  <h2>Amitosh Gain</h2>
  <h4>Front and Backend Developers</h4>
  <p>Email:amitosh.seu@gmail.com</p>
</div>

<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/shoeb.jpg" height="150" width="150">
    <img src="images/shoeb2.jpg" height="150" width="150">
</div>
  <h2>Obayed Ullah Khan</h2>
  <h4>Front and Backend Developers</h4>
  <p>Email:ouks_cseseu@yahoo.com</p>

</div>

<div class="containerCard">
  <div class="avatar-flip">
    <img src="images/tanim.jpg" height="150" width="150">
    <img src="images/tanim2.jpg" height="150" width="150">
  </div>
  <h2>Faysal Ahmed</h2>
  <h4>Front and Backend Developers</h4>
  <p>Email: ftahamad@gmail.com</p>
</div>



<?php include 'inc/footer.php';?>